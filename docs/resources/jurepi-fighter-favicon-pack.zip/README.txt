Jurepi favicon package

포함 파일:
- favicon.ico
- favicon-16x16.png
- favicon-32x32.png
- favicon-48x48.png
- favicon-64x64.png
- favicon-96x96.png
- favicon-128x128.png
- favicon-180x180.png
- favicon-192x192.png
- favicon-256x256.png
- favicon-512x512.png
- apple-touch-icon.png
- android-chrome-192x192.png
- android-chrome-512x512.png
- site.webmanifest
- favicon-usage.html

사용 방법:
1. 압축을 풀고 사이트의 public/ 폴더에 넣습니다.
2. favicon-usage.html 의 내용을 head 또는 metadata 설정에 반영합니다.
